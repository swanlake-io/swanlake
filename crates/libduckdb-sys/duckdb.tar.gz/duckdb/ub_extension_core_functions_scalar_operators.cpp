#include "extension/core_functions/scalar/operators/bitwise.cpp"

